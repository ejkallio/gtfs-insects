package com.yourcompany.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GtfsInsectsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GtfsInsectsApplication.class, args);
	}

}
